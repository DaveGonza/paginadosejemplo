<?php 
	include('clases/CindexgenerarConsultas.php');
	include_once('../css/librerias/JSON.php');
	//error_reporting(E_ERROR);

	//variables Objetos
	$json = new Services_JSON();
	$arrResp = array(); 
	
	//variables POST 
	$iOpcion					= 	isset($_POST["iOpcion"]) 					? $_POST["iOpcion"] : 0;
	$nombre						=	isset($_POST["nombre"]) 					? $_POST["nombre"] : 0;
	$id							=	isset($_POST["id"]) 						? $_POST["id"] : 0;
	$objTrabajador    			= 	isset($_POST["objTrabajador"]) 				? $_POST["objTrabajador"] : null;
	//$CasodePrueba				= 	isset($_POST["CasodePrueba"]) 				? $_POST["CasodePrueba"] : 0;

	switch($iOpcion)
	{
		case 1:
				$arrResp=CGeneralConsultas::GuardarDatosPersonales($objTrabajador);//
			break;
		case 2:
				$arrResp=CGeneralConsultas::BuscarDatosPersonales();//
			break;
		case 3:
				$arrResp=CGeneralConsultas::EliminarDatosPersonales($id);//
			break;
		case 4:
				$arrResp=CGeneralConsultas::EditarDatosPersonales($id);//
			break;				
		default:
				$arrResp="OPCION INCORRECTA FAVOR DE VERIFICAR OP:[".$iOpcion."];";
		break;
	}	
	echo $json->encode($arrResp);
 ?>