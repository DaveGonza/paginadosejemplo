<?php 
define("IP", 'localhost');//Aqui va la ip de la base de datos 
define("BASEDEDATOS", 'bdejemplo'); //aqui el nombre de la base de datos 
define("USUARIO", 'root'); //aqui el usuario de la base de datos 
define("PASSWORD", ''); //aqui la conseña de la base de datos
define("PUERTO", '3306'); //aqui la conseña de la base de datos



 ?>