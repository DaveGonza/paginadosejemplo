<?php 
	include('Conexiones.php');
	//include('../ConexionEnruter.php');

	/**
	 Aqui es la parte donde se hacen las consultas a base datos.
	 */
	class CGeneralConsultas
	{
		public static function GuardarDatosPersonales($objTrabajador)
		{
			$cNombre          = isset($objTrabajador['cNombre']) 			? $objTrabajador['cNombre'] : '';
			$cApellidoPa      = isset($objTrabajador['cApellidoPa']) 		? $objTrabajador['cApellidoPa'] : '';
			$cApellidoMa      = isset($objTrabajador['cApellidoMa']) 		? $objTrabajador['cApellidoMa'] : '';
			$cFechaNacimiento = isset($objTrabajador['cFechaNacimiento']) 	? $objTrabajador['cFechaNacimiento'] : '1900-01-01';
			$cDireccion       = isset($objTrabajador['cDireccion']) 		? $objTrabajador['cDireccion'] : '';
			$cTelefono        = isset($objTrabajador['cTelefono']) 			? $objTrabajador['cTelefono'] : '';
			$cEsCivil         = isset($objTrabajador['cEsCivil']) 			? $objTrabajador['cEsCivil'] : '';
			$cCurp            = isset($objTrabajador['cCurp']) 				? $objTrabajador['cCurp'] : '';
			$cRfc             = isset($objTrabajador['cRfc']) 				? $objTrabajador['cRfc'] : '';
			$cNss             = isset($objTrabajador['cNss']) 				? $objTrabajador['cNss'] : '';
			$cNivelEstudio    = isset($objTrabajador['cNivelEstudio']) 		? $objTrabajador['cNivelEstudio'] : '';

			$conexion =  new PDO("mysql:host=".IP.";port=".PUERTO.";dbname=".BASEDEDATOS, USUARIO, PASSWORD!=null&&PASSWORD!=""?PASSWORD:"");

			$cSql = "INSERT INTO datos_peroanles(nombre,apellido_paterno,apellido_materno,fechanacimineto,direccion,telefono,estadocivil,curp,rfc,nss,nivelEstudio)
					VALUES('$cNombre','$cApellidoPa','$cApellidoMa','$cFechaNacimiento','$cDireccion','$cTelefono','$cEsCivil','$cCurp','$cRfc','$cNss','$cNivelEstudio')";
			var_dump($cSql);

			$resultSet = $conexion->query($cSql);
			if ($resultSet) 
			{
				$datos->codigoRespuesta = 1;
				$datos->descripcion = "Hecho EliminarDatosPersonales()";
			}
			else
			{
				$datos->codigoRespuesta = 0;
				$datos->descripcion = "ALGO SALIO MAL fncalculosfinalespmg()";
			}
			return $datos;
			$cnxBd = null;
		}
		public static function GuardarDatosAutomovil()
		{

		}
		public static function BuscarDatosPersonales()
		{
			$datos = new stdClass();
			$arrDatos = array();
			$conexion =  new PDO("mysql:host=".IP.";port=".PUERTO.";dbname=".BASEDEDATOS, USUARIO, PASSWORD!=null&&PASSWORD!=""?PASSWORD:"");
			if ($conexion) 
			{
				$cSql = "SELECT id,nombre,apellido_paterno,apellido_materno,fechanacimineto,direccion,telefono,estadocivil,curp,rfc,nss,nivelEstudio FROM datos_peroanles";
		
				$resultSet = $conexion->query($cSql);
				if ($resultSet) 
				{
					foreach ($resultSet as $resultado) 
					{
						$arrDatos['id'][]           	= $resultado['id'];
						$arrDatos['nombre'][]           = $resultado['nombre'];
						$arrDatos['apellido_paterno'][] = $resultado['apellido_paterno'];
						$arrDatos['apellido_materno'][] = $resultado['apellido_materno'];
						$arrDatos['fechanacimineto'][]  = $resultado['fechanacimineto'];
						$arrDatos['direccion'][]        = $resultado['direccion'];
						$arrDatos['telefono'][]         = $resultado['telefono'];
						$arrDatos['estadocivil'][]      = $resultado['estadocivil'];
						$arrDatos['curp'][]             = $resultado['curp'];
						$arrDatos['rfc'][]              = $resultado['rfc']; 
						$arrDatos['nss'][]              = $resultado['nss'];
						$arrDatos['nivelEstudio'][]     = $resultado['nivelEstudio'];						
					}
				}
				$datos->datoscit = $arrDatos;
				$datos->codigoRespuesta = 1;
			}
			$conexion = null;		
			return $datos;
		}
		public static function EliminarDatosPersonales($id)
		{
			$datos = new stdClass();
			$arrDatos = array();
			$conexion =  new PDO("mysql:host=".IP.";port=".PUERTO.";dbname=".BASEDEDATOS, USUARIO, PASSWORD!=null&&PASSWORD!=""?PASSWORD:"");
			if ($conexion) 
			{
				$cSql = "DELETE FROM datos_peroanles WHERE id = $id";
		
				$resultSet = $conexion->query($cSql);
				if ($conexion) 
				{
					$datos->codigoRespuesta = 1;
					$datos->descripcion = "Hecho EliminarDatosPersonales()";
				}
				else
				{
					$datos->codigoRespuesta = 0;
					$datos->descripcion = "ALGO SALIO MAL fncalculosfinalespmg()";
				}
				return $datos;
				$cnxBd = null;	

			}
		}
		public static function EditarDatosPersonales($id)
		{
			$datos = new stdClass();
			$arrDatos = array();
			$conexion =  new PDO("mysql:host=".IP.";port=".PUERTO.";dbname=".BASEDEDATOS, USUARIO, PASSWORD!=null&&PASSWORD!=""?PASSWORD:"");
			if ($conexion) 
			{
				$cSql = "SELECT nombre,apellido_paterno,apellido_materno,fechanacimineto,direccion,telefono,estadocivil,curp,rfc,nss,nivelEstudio FROM datos_peroanles WHERE id = $id";
		
				$resultSet = $conexion->query($cSql);
				if ($resultSet) 
				{
					foreach ($resultSet as $resultado) 
					{	
						$arrDatos['nombre'][]           = $resultado['nombre'];
						$arrDatos['apellido_paterno'][] = $resultado['apellido_paterno'];
						$arrDatos['apellido_materno'][] = $resultado['apellido_materno'];
						$arrDatos['fechanacimineto'][]  = $resultado['fechanacimineto'];
						$arrDatos['direccion'][]        = $resultado['direccion'];
						$arrDatos['telefono'][]         = $resultado['telefono'];
						$arrDatos['estadocivil'][]      = $resultado['estadocivil'];
						$arrDatos['curp'][]             = $resultado['curp'];
						$arrDatos['rfc'][]              = $resultado['rfc']; 
						$arrDatos['nss'][]              = $resultado['nss'];
						$arrDatos['nivelEstudio'][]     = $resultado['nivelEstudio'];						
					}
				}
				$datos->datoscit = $arrDatos;
				$datos->codigoRespuesta = 1;
			}
			$conexion = null;		
			return $datos;
		}
	}


 ?>