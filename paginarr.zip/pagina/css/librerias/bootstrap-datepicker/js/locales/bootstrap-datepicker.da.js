/**
 * Danish translation for bootstrap-datepicker
 * Christian Pedersen <http://github.com/chripede>
 * Ivan Mylyanyk <https://github.com/imylyanyk>
 */
;(function($){
	$.fn.datepicker.dates['da'] = {
		days: ["søndag", "mandag", "tirsdag", "onsdag", "torsdag", "fredag", "lørdag"],
		daysShort: ["søn", "man", "tir", "ons", "tor", "fre", "lør"],
		daysMin: ["sø", "ma", "ti", "on", "to", "fr", "lø"],
		months: ["januar", "februar", "marts", "april", "maj", "juni", "juli", "august", "september", "oktober", "november", "december"],
		monthsShort: ["jan", "feb", "mar", "apr", "maj", "jun", "jul", "aug", "sep", "okt", "nov", "dec"],
		today: "I Dag",
		clear: "Nulstil"
	};
}(jQuery));
